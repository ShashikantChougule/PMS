package com.org.citius.pms.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
