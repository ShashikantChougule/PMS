package com.citiustech.procedure;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProcedureControllerTest {

}
