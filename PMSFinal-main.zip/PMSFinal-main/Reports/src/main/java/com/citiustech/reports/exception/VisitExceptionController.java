package com.citiustech.reports.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class VisitExceptionController {

	
}
