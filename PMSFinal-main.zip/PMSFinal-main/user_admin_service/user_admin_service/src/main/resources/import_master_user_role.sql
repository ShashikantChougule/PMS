INSERT INTO `userdb`.`user_role` (`id`, `role_name`, `role_type`) VALUES ('1', 'ADMIN', 'ADMIN');
INSERT INTO `userdb`.`user_role` (`id`, `role_name`, `role_type`) VALUES ('2', 'PHYSICIAN', 'EMPLOYEE');
INSERT INTO `userdb`.`user_role` (`id`, `role_name`, `role_type`) VALUES ('3', 'NURSE', 'EMPLOYEE');
INSERT INTO `userdb`.`user_role` (`id`, `role_name`, `role_type`) VALUES ('4', 'PATIENT', 'USER');