package com.citiustech.allergies;
/*
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.citiustech.allergies.model.Allergy;
import com.citiustech.allergies.model.repository.AllergyRepository;
import com.citiustech.allergies.service.AllergyService;

import java.util.stream.Collectors;
import java.util.stream.Stream;*/
/*
@RunWith(SpringRunner.class)
@SpringBootTest*/
public class AllergyControllerTest {

	/*
	 * @Autowired public AllergyService allergyService;
	 * 
	 * @MockBean private AllergyRepository allergyRepo;
	 * 
	 * @Test public void findAllAllergyTest() {
	 * when(allergyRepo.findAll()).thenReturn(Stream. of(new
	 * Allergy("Bos d 2.0101","Animal","Bovine","Bos taurus","Bos Bos d 2"
	 * ,"IgE but no biological test"), new
	 * Allergy("Bos d 2.0101","Animal","Bovine","Bos taurus","Bos Bos d 2"
	 * ,"IgE but no biological test")).collect(Collectors.toList()));
	 * assertEquals(2, allergyService.findAllAllergy().size()); }
	 * 
	 * @Test public void findAllergyById() { String id = "Bos d 2.0101"; Allergy
	 * allergy = new
	 * Allergy("Bos d 2.0101","Animal","Bovine","Bos taurus","Bos Bos d 2"
	 * ,"IgE but no biological test");
	 * when(allergyRepo.findById(id).get()).thenReturn(new
	 * Allergy("Bos d 2.0101","Animal","Bovine","Bos taurus","Bos Bos d 2"
	 * ,"IgE but no biological test")); assertEquals(allergy,
	 * allergyService.getAllergyById(id)); }
	 */
	
}
