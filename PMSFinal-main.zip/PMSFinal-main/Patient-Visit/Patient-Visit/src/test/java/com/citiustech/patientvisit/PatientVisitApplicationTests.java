package com.citiustech.patientvisit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientVisitApplicationTests {

	@Test
	void contextLoads() {
	}

}
