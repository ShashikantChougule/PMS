package com.citiustech.procedure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class ProcedureApplicationTests {

	@Test
	void contextLoads() {
	}

}
