INSERT INTO `userdb`.`user_status` (`id`, `user_status_code`, `user_status_description`) VALUES ('1', 'Active', 'ACTIVE ACCOUNT');
INSERT INTO `userdb`.`user_status` (`id`, `user_status_code`, `user_status_description`) VALUES ('2', 'Locked', 'ACCOUNT LOCKED');
INSERT INTO `userdb`.`user_status` (`id`, `user_status_code`, `user_status_description`) VALUES ('3', 'Disabled', 'ACCOUNT DISABLED');
INSERT INTO `userdb`.`user_status` (`id`, `user_status_code`, `user_status_description`) VALUES ('4', 'Deleted', 'ACCOUNT DELETED');
INSERT INTO `userdb`.`user_status` (`id`, `user_status_code`, `user_status_description`) VALUES ('5', 'Password_Expired', 'ACCOUNT PASSWORD EXPIRED');