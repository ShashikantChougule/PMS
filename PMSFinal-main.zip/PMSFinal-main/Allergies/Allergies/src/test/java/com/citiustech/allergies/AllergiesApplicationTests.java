package com.citiustech.allergies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class AllergiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
